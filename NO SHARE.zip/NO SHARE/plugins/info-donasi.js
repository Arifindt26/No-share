let handler = async (m, { conn }) => {
let fotonya = 'https://telegra.ph/file/893bb1c053e182782b085.jpg'
let sewa = `Hai Kak, Ingin Donasi?, Silahkan Donasi Ke Payment Yang Ada Di Bawah, Dengan Kamu Berdonasi Berarti Kamu Berkontribusi Dalam Perkembangan Bot Ini..

▧「 *P E M B A Y A R A N* 」

*🎗️E-Walet*
• Ovo = 0895-4199-16010
• Dana = 0895-4199-16010
• Gopay = 0895-4199-16010
• LinkAja = 0895-4199-16010
• Shopee = 0895-4199-16010

👤A/N : C**U

Terima Kasih Yang Sudah Donasi, Berapapun Donasi Kamu Akan Sangat Saya Hargai 👽
`
conn.sendFile(m.chat, fotonya, 'anu.jpg', sewa, m)
}
handler.help = ['donasi']
handler.tags = ['main']
handler.command = /^(donasi|donate)$/i

export default handler